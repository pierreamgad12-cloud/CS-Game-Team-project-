package game.gui;
import game.engine.Game;
import game.engine.Role;
import game.engine.Constants;
import game.engine.cells.Cell;
import game.engine.cells.DoorCell;
import game.engine.cells.CardCell;
import game.engine.cells.MonsterCell;
import game.engine.cells.ConveyorBelt;
import game.engine.cells.ContaminationSock;
import game.engine.exceptions.InvalidMoveException;
import game.engine.exceptions.OutOfEnergyException;
import game.engine.monsters.Monster;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.*;
import java.io.IOException;
import game.engine.Board;
import game.engine.cards.Card;
import game.engine.monsters.Dasher;
import game.engine.monsters.MultiTasker;
public class Main extends Application {
    private Scene gameScene;
    private Game game;
    private int turnNumber = 1;
    @Override
    public void start(Stage stage) {
        Label title = new Label("DOOR DASH: SCARER VS LAUGHER");
        RadioButton scarerB = new RadioButton("SCARER");
        RadioButton laugherB = new RadioButton("LAUGHER");
        ToggleGroup group = new ToggleGroup();
        scarerB.setToggleGroup(group);
        laugherB.setToggleGroup(group);
        scarerB.setSelected(true);
        Button startB = new Button("START NEW GAME");
        startB.setOnAction(e -> {
            Role selectedRole;
            Role opp;
            if (scarerB.isSelected()) {
                selectedRole = Role.SCARER;
                opp = Role.LAUGHER;
            } else {
                selectedRole = Role.LAUGHER;
                opp = Role.SCARER;
            }
            buildGameScene(stage, selectedRole, opp);
            stage.setScene(gameScene);
        });
        VBox rt = new VBox(20);
        rt.setAlignment(Pos.CENTER);
        rt.getChildren().addAll(title, scarerB, laugherB, startB);
        rt.setStyle("-fx-background-image: url('" +getClass().getResource("/game/gui/background.jpg").toExternalForm() +"');" +"-fx-background-size: cover;");
        title.setStyle("-fx-font-size: 30px; -fx-font-weight: bold; -fx-text-fill: orange;");
        scarerB.setStyle("-fx-font-size: 20px; -fx-text-fill: white; -fx-font-weight: bold;");
        laugherB.setStyle("-fx-font-size: 20px; -fx-text-fill: white; -fx-font-weight: bold;");
        startB.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: blue;");
        StackPane centeredRoot = new StackPane(rt);
        Scene scene = new Scene(centeredRoot, 500, 400);
        stage.setTitle("DoorDASH");
        stage.setScene(scene);
        stage.show();
    }

    private void buildGameScene(Stage stage, Role role, Role opp) {
        try {
            game = new Game(role);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        turnNumber = 1;
        GridPane board = new GridPane();
        board.setHgap(4);
        board.setVgap(4);
        board.setPadding(new Insets(5));
        board.setAlignment(Pos.CENTER);
        Label[] cells = new Label[100];
        String[] baseText = new String[100];
        String[] baseStyle = new String[100];
        Cell[][] engineCells = game.getBoard().getBoardCells();
        int cellNo = 0;    
        for (int row = 0; row < 10; row++) {
            for (int col = 0; col < 10; col++) {
                Cell engineCell = getEngineCell(engineCells, cellNo);
                String type = "Normal Cell";
                String style = "-fx-border-color: purple; -fx-background-color: pink; -fx-font-weight: bold;";

                if (cellNo == 0) {
                    type = "Start Cell";
                    style = "-fx-border-color: purple; -fx-background-color: orange; -fx-font-weight: bold;";
                }
                else if (engineCell instanceof DoorCell) {
                    DoorCell door = (DoorCell) engineCell;
                    type = door.getRole() + " Door\nEnergy: " + door.getEnergy();
                    if (door.getRole() == Role.SCARER) {
                        style = "-fx-border-color: purple; -fx-background-color: black; -fx-font-weight: bold; -fx-text-fill: white;";
                    } else {
                        style = "-fx-border-color: purple; -fx-background-color: lightgreen; -fx-font-weight: bold; -fx-text-fill: black;";
                    }
                }
                else if (engineCell instanceof MonsterCell) {
                    type = "Monster Cell";
                    style = "-fx-border-color: purple; -fx-background-color: red; -fx-font-weight: bold;";
                }
                else if (engineCell instanceof CardCell) {
                    type = "Card Cell";
                    style = "-fx-border-color: purple; -fx-background-color: yellow; -fx-font-weight: bold;";
                }
                else if (engineCell instanceof ConveyorBelt) {
                    type = "ConveyorBelt";
                    style = "-fx-border-color: purple; -fx-background-color: lightblue; -fx-font-weight: bold;";
                }
                else if (engineCell instanceof ContaminationSock) {
                    type = "ContaminationSock";
                    style = "-fx-border-color: purple; -fx-background-color: gray; -fx-font-weight: bold;";
                }
                Label cell = new Label(cellNo + "\n" + type);
                cell.setMinSize(65, 60);
                cell.setMaxSize(65, 60);
                cell.setPrefSize(65, 60);
                cell.setAlignment(Pos.CENTER);
                cell.setStyle(style);
                cell.setWrapText(true);
                cells[cellNo] = cell;
                baseText[cellNo] = cellNo + "\n" + type;
                baseStyle[cellNo] = style;
                int currentCell = cellNo;
                cell.setOnMouseClicked(e -> {
                    System.out.println("Clicked cell: " + currentCell);
                });
                int displayCol;
                if (row % 2 == 0) {
                    displayCol = col;
                } else {
                    displayCol = 9 - col;
                }
                board.add(cell, displayCol, row);
                cellNo++;
        }
        }

        updateBoard(cells, baseText, baseStyle);
        Label player = new Label("Player: " + game.getPlayer().getName() + " | Role: " + game.getPlayer().getRole() +" | Position: " + game.getPlayer().getPosition() +" | Energy: " + game.getPlayer().getEnergy());
        player.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: green;");
        Label oppp = new Label( "Opponent: " + game.getOpponent().getName() +" |Role: " + game.getOpponent().getRole() +" |Position: " + game.getOpponent().getPosition() +" |Energy: " + game.getOpponent().getEnergy());
        oppp.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: red;");
        Label monsterInfo = new Label("MONSTERS:\n" +game.getPlayer().getName() + " starts at cell 0\n" +game.getOpponent().getName() + " starts at cell 0" );
        monsterInfo.setStyle("-fx-font-size: 16px;" + "-fx-font-weight: bold;" +"-fx-text-fill: white;" +"-fx-background-color: black;" + "-fx-padding: 10;");
        Label monsterDetails = new Label(getMonsterDetails());
        monsterDetails.setWrapText(true);
        monsterDetails.setStyle("-fx-font-size: 13px;" +"-fx-font-weight: bold;" +"-fx-text-fill: white;" +"-fx-background-color: black;" +"-fx-padding: 10;" +"-fx-border-color: white;" +"-fx-border-width: 2;");
        Label instructions = new Label("GAME INSTRUCTIONS:\n\n" + "1. Choose whether to activate powerup before rolling\n" +"2. Roll dice to move the current monster\n" +"3. Card cells apply card effects\n" + "4. Freeze effect skips a turn\n" + "5. Doors show their energy value\n");
        instructions.setWrapText(true);
        instructions.setStyle("-fx-font-size: 15px;" +"-fx-font-weight: bold;" +"-fx-text-fill: white;" +"-fx-background-color: black;" +"-fx-padding: 20;");
        VBox leftBox = new VBox(20);
        leftBox.getChildren().addAll(instructions, monsterInfo,monsterDetails);
        leftBox.setAlignment(Pos.TOP_LEFT);
        Button powerupB = new Button("Activate Powerup");
        Button rollDiceB = new Button("Roll Dice");
        Label diceResult = new Label("Dice: -");
        Label monstertype = new Label("Current Monster: " + game.getCurrent().getName() +"\nType: " + game.getCurrent().getRole());
        Label powerupStatus = new Label("Powerup: Not activated");
        Label currturn = new Label("Current Turn: " + turnNumber);
        Label currentplayers = new Label("Current: " + game.getCurrent().getName() +" | Opponent: " + getCurrentOpponent().getName());
        Label carddrawn = new Label("Card Drawn: Engine handles card effect");
        Label skip = new Label("Skip Turn: No");
        Label actionMessage = new Label("Action: None");
        String buttonStyle ="-fx-font-size: 15px;" +"-fx-font-weight: bold;" +"-fx-background-color: Teal;" +"-fx-text-fill: white;" +"-fx-padding: 20;" +"-fx-border-color: black;" +"-fx-border-width: 5;";
        String smallBoxStyle = "-fx-font-size: 15px;" +"-fx-font-weight: bold;" + "-fx-background-color: Crimson;" + "-fx-text-fill: white;" +"-fx-padding: 20;" +"-fx-border-color: black;" + "-fx-border-width: 5;";
        powerupB.setStyle(buttonStyle);
        rollDiceB.setStyle(buttonStyle);
        diceResult.setStyle(smallBoxStyle);
        monstertype.setStyle(smallBoxStyle);
        powerupStatus.setStyle(smallBoxStyle);
        currturn.setStyle(smallBoxStyle);
        currentplayers.setStyle(smallBoxStyle);
        carddrawn.setStyle(smallBoxStyle);
        skip.setStyle(smallBoxStyle);
        actionMessage.setStyle(smallBoxStyle);

        powerupB.setOnAction(e -> {
            try {
                game.usePowerup();
                powerupStatus.setText("Powerup: Activated");
                actionMessage.setText("Action: " + game.getCurrent().getName() + " activated powerup");
                updateLabels(player, oppp, currentplayers, monstertype);
                monsterDetails.setText(getMonsterDetails());
                updateBoard(cells, baseText, baseStyle);
                Monster winner = game.getWinner();
                if (winner != null) {
                    buildGameOverScene(stage, winner);
                }
            } catch (OutOfEnergyException ex) {
                powerupStatus.setText("Powerup failed: Not enough energy");
                actionMessage.setText("Action blocked: Not enough energy for powerup");
                showInvalidAction("Not enough energy to activate powerup.");
            }
        });
        rollDiceB.setOnAction(e -> {
            Monster beforeTurn = game.getCurrent();
            if (beforeTurn.isFrozen()) {
                skip.setText("Skip Turn: " + beforeTurn.getName() + " skipped because of Freeze");
            } else {
                skip.setText("Skip Turn: No");
            }        
            try {
                Monster movingMonster = game.getCurrent();
                int oldPosition = movingMonster.getPosition();
                int oldEnergy = movingMonster.getEnergy();
                boolean hadShield = movingMonster.isShielded();

                Card possibleDrawnCard = null;
                int cardsBefore = Board.getCards().size();

                if (cardsBefore > 0) {
                    possibleDrawnCard = Board.getCards().get(0);
                }
                game.playTurn();
                int cardsAfter = Board.getCards().size();
                int newPosition = movingMonster.getPosition();
                int newEnergy = movingMonster.getEnergy();
                String msg = "";
                msg += "Action: " + movingMonster.getName() +
                        " moved from cell " + oldPosition +
                        " to cell " + newPosition;
                if (newEnergy > oldEnergy) {
                    msg += "\nEnergy increased: " + oldEnergy + " -> " + newEnergy;
                }
                else if (newEnergy < oldEnergy) {
                    msg += "\nEnergy decreased: " + oldEnergy + " -> " + newEnergy;
                }
                else {
                    msg += "\nEnergy unchanged: " + newEnergy;
                }

                if (hadShield && oldEnergy == newEnergy) {
                    msg += "\nShield may have blocked energy loss";
                }
                actionMessage.setText(msg);
                turnNumber++;
                currturn.setText("Current Turn: " + turnNumber);
                diceResult.setText("Dice: " + game.getLastRoll());
                if (cardsAfter < cardsBefore && possibleDrawnCard != null) {
                    carddrawn.setText( "Card Drawn: " + possibleDrawnCard.getName() +"\nEffect: " + possibleDrawnCard.getDescription() + "\nType: " + possibleDrawnCard.getClass().getSimpleName());
                } else {
                    carddrawn.setText("Card Drawn: None");
                }
                powerupStatus.setText("Powerup: Not activated");
                updateLabels(player, oppp, currentplayers, monstertype);
                monsterDetails.setText(getMonsterDetails());
                updateBoard(cells, baseText, baseStyle);
                System.out.println("Player position: " + game.getPlayer().getPosition());
                System.out.println("Player energy: " + game.getPlayer().getEnergy());
                System.out.println("Opponent position: " + game.getOpponent().getPosition());
                System.out.println("Opponent energy: " + game.getOpponent().getEnergy());
                Monster winner = game.getWinner();
                if (winner != null) {
                    buildGameOverScene(stage, winner);
                }
                else if (game.getPlayer().getPosition() == Constants.WINNING_POSITION) {
                    buildGameOverScene(stage, game.getPlayer());
                }
                else if (game.getOpponent().getPosition() == Constants.WINNING_POSITION) {
                    buildGameOverScene(stage, game.getOpponent());
                }
            } catch (InvalidMoveException ex) {
                skip.setText("Invalid Move: " + ex.getMessage());
                actionMessage.setText("Action blocked: " + ex.getMessage());
                showInvalidAction(ex.getMessage());
            }
        });
        VBox actionBox = new VBox(15);
        actionBox.getChildren().addAll( powerupB, rollDiceB,diceResult, monstertype,powerupStatus);
        actionBox.setAlignment(Pos.CENTER_LEFT);
        HBox bottomSection = new HBox(30);
        bottomSection.getChildren().addAll(leftBox, board, actionBox);
        bottomSection.setAlignment(Pos.CENTER);
        HBox statusBox = new HBox(10);
        statusBox.getChildren().addAll(currturn,currentplayers, carddrawn,skip,actionMessage);
        statusBox.setAlignment(Pos.CENTER);
        VBox gameRoot = new VBox(15);
        gameRoot.setStyle("-fx-background-image: url('" +getClass().getResource("/game/gui/b.jpg").toExternalForm() + "');" +"-fx-background-size: cover;");
        gameRoot.setPadding(new Insets(10));
        gameRoot.getChildren().addAll(player,oppp,bottomSection,statusBox);
        gameRoot.setAlignment(Pos.CENTER);
        gameScene = new Scene(gameRoot, 1200, 760);
    }
    private void buildGameOverScene(Stage stage, Monster winner) {
        Label title = new Label("GAME OVER");
        title.setStyle( "-fx-font-size: 40px;" + "-fx-font-weight: bold;" + "-fx-text-fill: pink;");
        Label winnerLabel = new Label( "Winner: " + winner.getName() +"\nRole: " + winner.getRole());
        winnerLabel.setStyle("-fx-font-size: 25px;" +"-fx-font-weight: bold;" +"-fx-text-fill: cyan;" );
        Label finalEnergy = new Label("FINAL ENERGY:\n\n" +game.getPlayer().getName() + ": " + game.getPlayer().getEnergy() + "\n" +game.getOpponent().getName() + ": " + game.getOpponent().getEnergy());
        finalEnergy.setStyle("-fx-font-size: 22px;" + "-fx-font-weight: bold;" +"-fx-text-fill: white;");
        Button back = new Button("Return to Start");
        back.setStyle("-fx-font-size: 18px;" + "-fx-font-weight: bold;" +"-fx-background-color: white;" +"-fx-text-fill: black;" );
        
        back.setOnAction(e -> {
            start(stage);
        });
        VBox root = new VBox(25);
        root.getChildren().addAll(title, winnerLabel, finalEnergy, back);
        root.setAlignment(Pos.CENTER);
        root.setStyle( "-fx-background-image: url('" +getClass().getResource("/game/gui/gameover.jpg").toExternalForm() +"');" + "-fx-background-size: cover;");
        Scene gameOverScene = new Scene(root, 700, 500);
        stage.setScene(gameOverScene);
    } 
    private Cell getEngineCell(Cell[][] cells, int index) {
        int row = index / Constants.BOARD_COLS;
        int col = index % Constants.BOARD_COLS;
        if (row % 2 == 1) {
            col = Constants.BOARD_COLS - 1 - col;
        }
        return cells[row][col];
    }
    private Monster getCurrentOpponent() {
        if (game.getCurrent() == game.getPlayer()) {
            return game.getOpponent();
        } else {
            return game.getPlayer();
        }
    }
    private void updateLabels(Label player, Label oppp, Label currentplayers, Label monstertype) {
        player.setText( "Player: " + game.getPlayer().getName() + " |Role: " + game.getPlayer().getRole() +" |Position: " + game.getPlayer().getPosition() +" |Energy: " + game.getPlayer().getEnergy());
        oppp.setText("Opponent: " + game.getOpponent().getName() +" |Role: " + game.getOpponent().getRole() +" |Position: " + game.getOpponent().getPosition() +"|Energy: " + game.getOpponent().getEnergy());
        currentplayers.setText("Current: " + game.getCurrent().getName() +" | Opponent: " + getCurrentOpponent().getName());
        monstertype.setText("Current Monster: " + game.getCurrent().getName() +"\nType: " + game.getCurrent().getRole());
    }

    private void updateBoard(Label[] cells, String[] baseText, String[] baseStyle) {
        Cell[][] engineCells = game.getBoard().getBoardCells();
        for (int i = 0; i < cells.length; i++) {
            Cell engineCell = getEngineCell(engineCells, i);
            String text = baseText[i];
            String style = baseStyle[i];
            if (engineCell instanceof DoorCell) {
                DoorCell door = (DoorCell) engineCell;
                if (door.isActivated()) {
                    text = text + "\nUSED";
                    style = style +"-fx-background-color: violet;" +"-fx-text-fill: white;" +"-fx-opacity: 0.9;";
                }
            }
            if (engineCell instanceof MonsterCell) {
                MonsterCell monsterCell = (MonsterCell) engineCell;
                text = text + "\n" + monsterCell.getCellMonster().getName();
            }
            cells[i].setText(text);
            cells[i].setStyle(style);
        }
        int playerPosition = game.getPlayer().getPosition();
        int opponentPosition = game.getOpponent().getPosition();
        String playerText = "\nPlayer";
        String opponentText = "\nOpponent";
        if (game.getPlayer().isConfused()) {
            playerText += "\nCONFUSED";
        }
        if (game.getOpponent().isConfused()) {
            opponentText += "\nCONFUSED";
        }
        cells[playerPosition].setText( cells[playerPosition].getText() + playerText);
        cells[opponentPosition].setText(cells[opponentPosition].getText() + opponentText);
    }
    private String getMonsterDetails() {
        String s = "";
        s += "MONSTER DETAILS:\n\n";
        s += getOneMonsterDetails(game.getPlayer());
        s += "\n--------------------\n";
        s += getOneMonsterDetails(game.getOpponent());
        return s;
    }
    private String getOneMonsterDetails(Monster m) {
        String s = "";
        s += "Name: " + m.getName() + "\n";
        s += "Original Role: " + m.getOriginalRole() + "\n";
        if (m.isConfused()) {
            s += "Current Role: " + m.getRole() + " (CONFUSED)\n";
        } else {
            s += "Current Role: " + m.getRole() + "\n";
        }
        s += "Type: " + m.getClass().getSimpleName() + "\n";
        s += "Energy: " + m.getEnergy() + "\n";
        s += "Position: " + m.getPosition() + "\n";
        s += "Status Effects: " + getStatusEffects(m) + "\n";

        return s;
    }
    private String getStatusEffects(Monster m) {
        String s = "";
        if (m.isShielded()) {
            s += "Shield ";
        }
        if (m.isFrozen()) {
            s += "Frozen ";
        }
        if (m.isConfused()) {
            s += "Confusion turns: " + m.getConfusionTurns() + " ";
        }
        if (m instanceof Dasher) {
            Dasher d = (Dasher) m;
            if (d.getMomentumTurns() > 0) {
                s += "Momentum Rush turns: " + d.getMomentumTurns() + " ";
            }
        }
        if (m instanceof MultiTasker) {
            MultiTasker mt = (MultiTasker) m;

            if (mt.getNormalSpeedTurns() > 0) {
                s += "Focus Mode turns: " + mt.getNormalSpeedTurns() + " ";
            }
        }
        if (s.equals("")) {
            s = "None";
        }
        return s;
    }
    private void showInvalidAction(String reason) {
        Stage popup = new Stage();
        Label title = new Label("Invalid Action");
        Label message = new Label(reason);
        Button close = new Button("Close");
        close.setOnAction(e -> {
            popup.close();
        });
        title.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: red;");
        message.setStyle("-fx-font-size: 19px; -fx-font-weight: bold;-fx-text-fill: white;");
        close.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;-fx-text-fill: red;");
        VBox root = new VBox(15);
        root.getChildren().addAll(title, message, close);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-image: url('" +getClass().getResource("/game/gui/warning.png").toExternalForm() +"');" +"-fx-background-size: cover;" +"-fx-padding: 20;" +"-fx-border-color: white;" +"-fx-border-width: 3;");
        Scene scene = new Scene(root, 350, 350);
        popup.setTitle("Invalid action");
        popup.setScene(scene);
        popup.show();
    }
    public static void main(String[] args) {
        launch();
    }
}